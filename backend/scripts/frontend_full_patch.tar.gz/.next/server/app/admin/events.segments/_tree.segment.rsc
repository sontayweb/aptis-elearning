:HL["/_next/static/chunks/0m34vyhx5yh_a.css","style"]
:HL["https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,400..900;1,400..900&display=swap","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4116,"slots":{"children":{"name":"admin","param":null,"prefetchHints":4160,"slots":{"children":{"name":"events","param":null,"prefetchHints":4192,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}}}},"staleTime":300,"buildId":"XOPhY0pcBX1aP-MMyW7Ih"}
