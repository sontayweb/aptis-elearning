var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/import-sheet/route.js")
R.c("server/chunks/[root-of-the-server]__0ciwszt._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_import-sheet_route_actions_0i2y9wq.js")
R.m(79238)
module.exports=R.m(79238).exports
